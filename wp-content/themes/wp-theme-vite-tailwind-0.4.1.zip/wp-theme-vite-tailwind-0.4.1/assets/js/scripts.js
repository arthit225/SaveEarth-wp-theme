document.addEventListener("DOMContentLoaded", function(){
  // Handler when the DOM is fully loaded
  console.log('js executed...');
});
